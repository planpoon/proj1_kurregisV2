package Controller;

import Model.DBConnector;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class mainPageController {

    private DBConnector dbConnector = new DBConnector();
    private int buttonNumber = 0;
    @FXML
    private List<Button> buttonList = new ArrayList<>();
    @FXML
    private AnchorPane anchorPane = new AnchorPane();
    private SubjectInfoPageController subjectInfoPageController = new SubjectInfoPageController();



    @FXML
    public void initialize() {
        generateButton();
        Connection connection = null;
        Statement statement = null;
        try {
            for (int semester = 1; semester <= 8; semester++) {
                int xValue = ((semester - 1) * 300) + 35;
                ArrayList<String> subjectIDArr = new ArrayList<>();
                ArrayList<String> subjectNameArr = new ArrayList<>();
                Class.forName("org.sqlite.JDBC");
                connection = DriverManager.getConnection("jdbc:sqlite:subjectInfoDB.db");
                System.out.println("initialize");
                statement = connection.createStatement();
                String sqlCommand = String.format("SELECT ID,NAME,CREDIT,PREREQUIRE,ISPASSED FROM subjectInfoTable WHERE SEM=%d", semester);
                ResultSet resultSet = statement.executeQuery(sqlCommand);

                while (resultSet.next()) {
                    subjectNameArr.add(resultSet.getString("NAME"));
                    subjectIDArr.add(resultSet.getString("ID"));
                }
                for (int subject = 1; subject <= subjectNameArr.size(); subject++) {
                    final int subjectIndex = subject-1;
                    int yValue = (40*subject)+20;
                    anchorPane.getChildren().add(buttonList.get(buttonNumber));
                    buttonList.get(buttonNumber).setLayoutX(xValue);
                    buttonList.get(buttonNumber).setLayoutY(yValue);
                    buttonList.get(buttonNumber).setText(subjectNameArr.get(subject-1));
                    buttonList.get(buttonNumber).setOnMouseClicked(mouseEvent -> {
                        if (mouseEvent.getButton() == MouseButton.SECONDARY){
                            passingSubjectData(subjectIDArr.get(subjectIndex));
                        }
                    });
                    buttonNumber++;
                }
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.err.println(e.getStackTrace()[0].getLineNumber());
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println(e.getStackTrace()[0].getLineNumber());
        }
    }

    private int countRow(int sem) {
        Connection connection = null;

        int count = 0;
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:subjectInfoDB.db");
            System.out.println("count row");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT COUNT(*) FROM subjectInfoTable WHERE SEM=" + sem);
            while (resultSet.next()) {
                count = resultSet.getInt(1);
            }
            return count;

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.err.println(e.getStackTrace()[0].getLineNumber());
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println(e.getStackTrace()[0].getLineNumber());
        }
        return count;
    }

    private void generateButton() {
        Connection connection = null;

        int count = 0;
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:subjectInfoDB.db");
            System.out.println("generate button");
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("SELECT COUNT(*) FROM subjectInfoTable");
            while (rs.next()) {
                count = rs.getInt(1);
            }
            for (int i = 0; i <count ; i++) {
                buttonList.add(new Button("button"+i));
            }
//            System.out.println(buttonList.size());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.err.println(e.getStackTrace()[0].getLineNumber());
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println(e.getStackTrace()[0].getLineNumber());
        }
    }
    private void passingSubjectData(String subjectID){
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("../View/subjectInfoPage.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Subject information ");
            stage.setScene(new Scene(root, 500, 300));
            SubjectInfoPageController subjectInfoPageController = loader.getController();
            subjectInfoPageController.initData(subjectID);

            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
