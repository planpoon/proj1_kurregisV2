package Model;


import org.sqlite.JDBC.*;
import java.sql.*;

public class DBConnector {

    public DBConnector() {
        super();
    }

    public void addSubject(String ID,String subjectName,int credit,int sem){
        Connection connection = null;
        Statement statement = null;
        try{
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:subjectInfoDB.db");
            connection.setAutoCommit(false);
            System.out.println("DB connected");

            statement = connection.createStatement();
            String sql = "INSERT INTO subjectInfoTable (ID,NAME,CREDIT,PREREQUIRE,SEM,ISPASSED) " + "VALUES (?,?,?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,ID);
            preparedStatement.setString(2,subjectName);
            preparedStatement.setInt(3,credit);
            preparedStatement.setInt(5,sem);
            preparedStatement.setBoolean(6,false);

            preparedStatement.executeUpdate();

            statement.close();
            connection.commit();
            connection.close();
        }catch (ClassNotFoundException e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        } catch (SQLException e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        System.out.println("Records created successfully");
    }

    public void addSubject(String ID,String subjectName,int credit,int sem,String preReSub){
        Connection connection = null;
        Statement statement = null;
        try{
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:subjectInfoDB.db");
            connection.setAutoCommit(false);
            System.out.println("DB connected");

            statement = connection.createStatement();
            String sql = "INSERT INTO subjectInfoTable (ID,NAME,CREDIT,PREREQUIRE,SEM,ISPASSED) " + "VALUES (?,?,?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,ID);
            preparedStatement.setString(2,subjectName);
            preparedStatement.setInt(3,credit);
            preparedStatement.setString(4,preReSub);
            preparedStatement.setInt(5,sem);
            preparedStatement.setBoolean(6,false);

            preparedStatement.executeUpdate();

            statement.close();
            connection.commit();
            connection.close();
        }catch (ClassNotFoundException e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        } catch (SQLException e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        System.out.println("Records created successfully");
    }

}
